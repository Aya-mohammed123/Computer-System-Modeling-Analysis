#include <iostream>
#include <vector>
#include <limits>
#include <cmath>
using namespace std;

class LaggedFibonacciGenerator {
private:
    float j, k, m;
    int subtraction;
    vector<float> sequence;

    float getValidFloat(const string& prompt, float minValue = 0) {
        float num;
        do {
            cout << prompt;
            cin >> num;
            if (cin.fail() || num < minValue) {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout << "Invalid input. Please enter a float greater than or equal to " << minValue << ".\n";
            } else {
                break;
            }
        } while (true);
        return num;
    }

    float calcXor(float num1, float num2) {
        return static_cast<int>(num1) ^ static_cast<int>(num2);
    }

    float calcAnd(float num1, float num2) {
        return static_cast<int>(num1) & static_cast<int>(num2);
    }

    float calcOr(float num1, float num2) {
        return static_cast<int>(num1) | static_cast<int>(num2);
    }

public:
    LaggedFibonacciGenerator() {
        j = getValidFloat("Enter the lag 'j': ", 0);
        k = getValidFloat("Enter the lag 'k': ", 0);
        m = getValidFloat("Enter the modulus: ", 0);
    }

    void generateSequence() {
        int op, count;
        count = getValidFloat("Enter the number of random numbers you want to generate: ", 0);
        do {
                op = getValidFloat("Choose a number of binary operator\n1. (+)\n2. (-)\n3. (*)\n4. (XOR)\n5. (and)\n6. (or): ", 0);
                if (op < 1 || op > 6) {
                    cout << "Invalid operator. Please enter a number from 1 to 6.\n";
                }
        } while (op < 1 || op > 6);
        float initialValue;
        for (int i = 0; i < k; ++i) {
            initialValue = getValidFloat("Enter the initial value x" + to_string(i) + ": ", 0);
            sequence.push_back(initialValue);
        }
        for (int i = 0; i < count; ++i) {
            float xi = k + i ;
            float firstOpValue = sequence[xi-j];

            float secondOpValue = sequence[xi-k];

            float result;
            switch (op) {
                case 1:
                    result = (static_cast<int>(firstOpValue) + static_cast<int>(secondOpValue)) % static_cast<int>(m);
                    break;
                case 2:
                   subtraction = static_cast<int>(firstOpValue) - static_cast<int>(secondOpValue);
                   result = (subtraction % static_cast<int>(m) + static_cast<int>(m)) % static_cast<int>(m);
                   break;
                case 3:
                    result = (static_cast<int>(firstOpValue) * static_cast<int>(secondOpValue)) % static_cast<int>(m);
                    break;
                case 4:
                    result = calcXor(firstOpValue, secondOpValue);
                    break;
                case 5:
                    result = calcAnd(firstOpValue, secondOpValue);
                    break;
                case 6:
                    result = calcOr(firstOpValue, secondOpValue);
                    break;
            }
            float RN = result / m;
            cout << "x" << xi << ": " << result << "\nrandomNumber: " << RN << endl;
            sequence.push_back(result);
        }
    }
};

int main() {
    LaggedFibonacciGenerator LFG;
    LFG.generateSequence();
    return 0;
}
