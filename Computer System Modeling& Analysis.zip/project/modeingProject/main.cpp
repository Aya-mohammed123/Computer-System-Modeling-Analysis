#include<iostream>
#include<algorithm>
#include<cstring>
#include<bits/stdc++.h>
#include <limits>
#include <cmath>
#include<string>
using namespace std;

class I_C_G {
private:
    double seed;
    double a;
    double m;

public:

    void setParameters(double seed, double a, double m)
	{
        this->seed = seed;
        this->a = a;
        this->m = m;
    }

    void I_C_G_Numbers(int n)
	 {
        double x = seed;
        double random_numbers[n];


        for (int i = 0; i <=n; ++i)
		 {
            x = fmod((a / x), m);
            random_numbers[i] = x / m;
        }

        //diplay Generated Random Numbers
        cout << "Generated Random Numbers:" << endl;
        for (int i = 0; i < n; ++i)
		 {
            cout << random_numbers[i] << endl;
        }
    }
};
class KS_test
 {
private:
    float D,D1_alpha,alpha;
    float*Dplus,*Dminus;
    float*row_one,*row_two;
    int n;
    float*numbers;
public:
    KS_test()
     {
        Dplus = nullptr;
        Dminus = nullptr;
        row_one = nullptr;
        row_two = nullptr;
        numbers = nullptr;
    }
    ~KS_test()
     {
        delete[] Dplus;
        delete[] Dminus;
        delete[] row_one;
        delete[] row_two;
        delete[] numbers;
    }

    void get_data()
     {
        do {
            cout << "Enter the number of generated numbers (must be positive): ";
            cin >> n;
            if (n <= 0) {
                cout << "Number of generated numbers must be positive." << endl;
            }
        } while (n <= 0);

        numbers = new float[n];
        row_one = new float[n];
        row_two = new float[n];
        Dplus = new float[n];
        Dminus = new float[n];

        cout << "Enter array of " << n<<" size: " << endl;
        for (int i = 0; i < n; i++) {
            cout << "Enter arr[" << i + 1 << "]: " << endl;
            cin >> numbers[i];
              while (numbers[i] <= 0) {
                cout << "Array elements must be positive. Enter arr[" << i + 1 << "] again: ";
                cin >> numbers[i];
              }

        }

        // Sorting array
        for (int i = 0; i < n; i++)
            {
            for (int j = i + 1; j < n; j++)
            {
                if (numbers[i] > numbers[j])
                {
                    float temp = numbers[j];
                    numbers[j] = numbers[i];
                    numbers[i] = temp;
                }
            }
        }
    }

    void KS_Table()
     {
        for (int i = 0; i < n; i++)
            {
            int j;
            j = i + 1;
            row_one[i] = (float)j / n;
            row_two[i] = (float)i / n;
            Dplus[i] = row_one[i] - numbers[i];
            Dminus[i] = numbers[i] - row_two[i];
        }
    }

    void display()
     {
        cout << endl;
        float Dplusmax = Dplus[0];
        float Dminusmax = Dminus[0];
        for (int i = 1; i < n; i++)
            {
            if (Dplus[i] > Dplusmax)
             {
                Dplusmax = Dplus[i];
            }
            if (Dminus[i] > Dminusmax)
            {
                Dminusmax = Dminus[i];
            }
        }
        cout << "D+ max: " << Dplusmax << endl;
        cout << "D- max: " << Dminusmax << endl;
        cout << "D = max(" << Dplusmax << ", " << Dminusmax << ") =";
        if (Dplusmax > Dminusmax)
            {
            D = Dplusmax;
        }
        else
            {
            D = Dminusmax;
        }
        cout << D << endl;
    }

    void test()
    {
        cout << "Enter the Alpha value:" << endl;
        cin >> alpha;

        while (alpha <= 0) {
            cout << "Alpha value must be positive. Enter again: ";
            cin >> alpha;
        }
        double D1_alpha = sqrt(-0.5 * log(alpha / 2.0)) / sqrt(n);

        if (D <= D1_alpha)
            {
            cout << "The test is not rejected." << endl;
        }

        else
            {
            cout << "The test is rejected." << endl;
        }
    }
};
class MultipleRecursiveGenerator
 {
public:
    void BakinamOutput()
	{
        cout << "========================Bakinam MOhamed===========================" << endl;
  cout << endl;
  cout<<endl;
    double R;
    double q;
    cout << "PLEASE,ENTER THE NO THAT ENTERED FOR EACH (A&X): "<<endl;
    //the no of multipliers is apply on the no of initial values
    cin >> q;
    vector<double> x(q);
    cout<<endl;
    cout<<"----------------------------------"<<endl;
    int m;
    cout << "PLEASE,ENTER THE MODULUS"<<endl;
    cin >> m;
    cout<<"===================================="<<endl;
    double no;
    cout << "PLEASE,ENTER HOW MANY NUMBERS WNANTS TO GENERATE: "<<endl;
    cin >> no;
    cout<<endl;
    cout<<"===================================="<<endl;
    cout << "PLEASE,ENTER THE INITIAL VALUES : "<<endl;
    for (int i = 0; i < q; i++)
    {
         do
        {
            cout << "ENTER THE VALUE X[" << i << "]: ";
            cin >> x[i];
            cout<<endl;
            if (x[i]< 0)
            {
                cout << "PLEASE ENTER POSITIVE VALUE!!!!!" << endl;
            }
        }
        while (x[i] < 0);
    }
    cout<<"================================================="<<endl;

    vector<double> a(q);
    cout << "PLEASE,ENTER THE VALUES OF INITIAL VALUES a1,a2,a3,....aq is: "<<endl;
    for (int i = 0; i < q; i++)
    {
    	do
        {
            cout << "ENTER A POSITIVE VALUE FOR A[" << i << "]: ";
            cin >> a[i];
            cout<<endl;
            if (a[i]<0)
            {
                cout << "PLEASE ENTER POSITIVE VALUE!!!!!." << endl;
            }
        }
        while (a[i] < 0);
    }

    for (int i = 0; i < no; i++)
    {
        double newXv = 0;
        for (int j = 0; j < q; j++)
        {
            newXv += a[j] * x[j];
        }
        newXv = fmod(newXv, m);

        x.erase(x.begin());

        x.push_back(newXv);

        R = (newXv) / m;
        cout<<endl;
        cout<<"====================================="<<endl;
        cout << "THE RANDOM VALUES AFTER THEM ARE IN ORDER:"<<"\t"<<R<<endl;
    }
}
};
class LaggedFibonacciGenerator {
private:
    float j, k, m;
    int subtraction;
    vector<float> sequence;

    float getValidFloat(const string& prompt, float minValue = 0)
    {
        float num;
        do {
            cout << prompt;
            cin >> num;
            if (cin.fail() || num < minValue)
                {
                cin.clear();
                cin.ignore(numeric_limits<streamsize>::max(), '\n');
                cout << "Invalid input. Please enter a float greater than or equal to " << minValue << ".\n";
            }
            else
                {
                break;
            }
        }
        while (true);
        return num;
    }

    float calcXor(float num1, float num2)
     {
        return static_cast<int>(num1) ^ static_cast<int>(num2);
    }

    float calcAnd(float num1, float num2)
    {
        return static_cast<int>(num1) & static_cast<int>(num2);
    }

    float calcOr(float num1, float num2)
    {
        return static_cast<int>(num1) | static_cast<int>(num2);
    }

public:
    LaggedFibonacciGenerator()
    {
        j = getValidFloat("Enter the lag 'j': ", 0);
        k = getValidFloat("Enter the lag 'k': ", 0);
        m = getValidFloat("Enter the modulus: ", 0);
    }

    void generateSequence()
     {
        int op, count;
        count = getValidFloat("Enter the number of random numbers you want to generate: ", 0);
        do
            {
                op = getValidFloat("Choose a number of binary operator\n1. (+)\n2. (-)\n3. (*)\n4. (XOR)\n5. (and)\n6. (or): ", 0);
                if (op < 1 || op > 6) {
                    cout << "Invalid operator. Please enter a number from 1 to 6.\n";
                }
        } while (op < 1 || op > 6);
        float initialValue;
        for (int i = 0; i < k; ++i) {
            initialValue = getValidFloat("Enter the initial value x" + to_string(i) + ": ", 0);
            sequence.push_back(initialValue);
        }
        for (int i = 0; i < count; ++i) {
            float xi = k + i ;
            float firstOpValue = sequence[xi-j];

            float secondOpValue = sequence[xi-k];

            float result;
            switch (op) {
                case 1:
                    result = (static_cast<int>(firstOpValue) + static_cast<int>(secondOpValue)) % static_cast<int>(m);
                    break;
                case 2:
                   subtraction = static_cast<int>(firstOpValue) - static_cast<int>(secondOpValue);
                   result = (subtraction % static_cast<int>(m) + static_cast<int>(m)) % static_cast<int>(m);
                   break;
                case 3:
                    result = (static_cast<int>(firstOpValue) * static_cast<int>(secondOpValue)) % static_cast<int>(m);
                    break;
                case 4:
                    result = calcXor(firstOpValue, secondOpValue);
                    break;
                case 5:
                    result = calcAnd(firstOpValue, secondOpValue);
                    break;
                case 6:
                    result = calcOr(firstOpValue, secondOpValue);
                    break;
            }
            float RN = result / m;
            cout << "x" << xi << ": " << result << "\nrandomNumber: " << RN << endl;
            sequence.push_back(result);
        }
    }
};

class MidSquare
 {

public:

    public:

     void Random_mid(int value, int num_of_rounds, int m) {
        cout << "Sequence of Random Numbers: " << endl;
        cout << "i         xi            x^2              mid          Ri" << endl;
        cout << "--------------------------------------------------------------------" << endl;

        int x = value;

         for (int i = 0; i < num_of_rounds; i++) {
        int squared = x * x;
        int mid = (squared / 100) % 10000;
        double Ri = double(mid) / m;

        // Convert squared to string to count digits
        string squared_str = to_string(squared);
        // Check if squared number has 7 digits
        if (squared_str.length() == 7) {
            // If 7 digits, add leading zero
cout << i << "         " << x << "         "<<"0"<<squared<<"         "<<mid<<"          "<<Ri<<endl;            }

        // Output squared number according to conditions
        // If 7 digits, output squared number

         else {
            // If 8 digits, don't add leading zero

cout << i << "         " << x << "         "<<squared<<"         "<<mid<<"          "<<Ri<<endl;            }


        cout << "--------------------------------------------------------------------" << endl;

        x = mid;
    }
    }
};
class TeachingAssistant
{
		public:
		void OmarPassword()
        {
         cout<<"\t\t";
         for (int r = 0; r < 96; r++)
         {
            cout << "=";
         }
         cout<<endl;
         string pass;
         cout<<endl;
         cout<<endl;
         cout<<"             :)HELLO ENG/OMAR HATEM:)"<<endl;
         cout<<endl;
         cout<<"\t\t Enter TA password: ";
         cin>>pass;
         do
         {
          if(pass!="omar@123")
           {
               cout<<"\t\t\t\t""          Wrong password please try again"" : \n";
               cout<<endl;
               cout<<"\t\t\t\t Enter Correct password: ";
               cin>>pass;
           }
         else
          {
             system("cls");
             break;
          }
         }
		 while(true);
        }
        void HabibaPassword()
        {

         cout<<"\t\t";
         for (int r = 0; r < 96; r++)
         {
            cout << "=";
         }
         cout<<endl;
         cout<<endl;
         string pass;
         cout<<endl;
         cout<<endl;
         cout<<"          HELLO ENG/HABIBA ELKHOLY"<<endl;
         cout<<endl;
         cout<<"\t\t ENTER TA PASSWORD: ";
         cin>>pass;
         do
         {
          if(pass!="habiba@123")
           {
               cout<<"\t\t\t\t Wrong password please try again :( \n";
               cout<<endl;
               cout<<"\t\t\t\t Please,Enter Correct password: ";
               cin>>pass;
           }
         else
          {
             system("cls");
             break;
          }
         }
		 while(true);
        }

        void DisplayList()
        {
        	cout<<"\t\t\t\t YOU WILL DISCUSS THE FOLLOWING STUDENTS FROM 10:20 TO 10:30 \t\t\t\t"<<endl;
        	cout<<endl;
            cout << "\t\t  Name                     ID        ALGORITHM:\n";
            cout<<endl;
            cout << "\t\t Noha Elsayed          42110440      LCG & KS  \n";
            cout << "\t\t Bakinam Mohamed       42110396      MRG       \n";
            cout << "\t\t Aya MOhamed           42110153      LRG       \n";
            cout << "\t\t Aya Saleh             42110294      MSM       \n";
            cout<<endl;
            cout<<"======================================================"<<endl;
        }
        void names_list()
        {
        	cout<<"\t\t Who will dicuss now? "<<endl;
            cout<<"\t\t 1. Noha"<<endl;
            cout<<"\t\t 2. bakinam"<<endl;
            cout<<"\t\t 3. aya mohamed"<<endl;
            cout<<"\t\t 4. aya saleh"<<endl;
            cout<<"-----------------------------------------------------"<<endl;

		}
        void chooseAlgorithm(int choice)
        {
            	 char x;
            int choice1;
            TeachingAssistant t;
        	switch (choice)
            {
            	case 1:
            		{
            			cout<<"=================Noha ELsayed===================="<<endl;
            			cout<<endl;
            		 int subChoice;

        cout << "Choose an option for Noha Elsayed:" << endl;
        cout << "1. I_C_G" << endl;
        cout << "2. K_S" << endl;
        cout<<endl;
        cout << "Enter your choice: ";
        cin >> subChoice;
        cout<<endl;
        system("cls");
        switch (subChoice)
        {
        case 1:
        {
        		cout<<endl;
        	cout<<"===============I_C_G==============="<<endl;
        		cout<<endl;
        		cout<<endl;
        double seed, a, m;
        int n;
        // Input validation for seed
        do {
            cout << "Please Enter seed (must be positive): ";
            cin >> seed;
            if (seed <= 0) {
                cout << "Seed cannot be negative or 0" << endl;
            }
        } while (seed <= 0);

        // Input validation for a
        do {
            cout << "Please Enter Multiplier (must be positive): ";
            cin >> a;
            if (a < 0) {
                cout << " Multiplier cannot be negative" << endl;
            }
        } while (a <= 0);

        // Input validation  for m
        do {
            cout << "Please Enter Modulus (must be positive): ";
            cin >> m;
            if (m < 0) {
                cout << " Modulus cannot be negative" << endl;
            }
        } while (m <= 0);

        // Input validation  for n
        do {
            cout << "Please Enter Number of random numbers to generate (must be positive): ";
            cin >> n;
            if (n < 0) {
                cout << " Number of random numbers cannot be negative" << endl;
            }
        }
		 while (n <= 0);

        I_C_G noha;
        noha.setParameters(seed, a, m);
        noha.I_C_G_Numbers(n);
            exit(0);
        }
        case 2:
        	{
        		cout<<"===================K_S======================"<<endl;
        		cout<<endl;
        		cout<<endl;
        	  KS_test ks1;
                   ks1.get_data();
                   ks1.KS_Table();
                   ks1.display();
                    ks1.test();
    cout<< "Do you want complete (y/n) ?";
            cin>>x;
 if(x=='y'){system("cls");
                   t.DisplayList();
                   t.names_list();
                   cout<<"please,select choice:"<<endl;
                   cin>>choice1;
                   system("cls");
	               t.chooseAlgorithm(choice1);

            }
            else{
                cout<<"Thank you :)"<<endl;
                exit(0);
            }
            break;
    }
}

}
        case 2:

            MultipleRecursiveGenerator beka;
            beka.BakinamOutput();
            cout<< "Do you want complete (y/n) ?";
            cin>>x;
            if(x=='y')
			{system("cls");
                   t.DisplayList();
                   t.names_list();
                   cout<<"Please,select choice:"<<endl;
                   cin>>choice1;
                   system("cls");
	               t.chooseAlgorithm(choice1);

            }
            else{
                cout<<" :)Thank you :)"<<endl;
                exit(0);
            }
            break;
        default:
           // LaggedFibonacciGenerator LFG;
            //LFG.generateSequence();
            cout<<" Invalid choice"<<endl;
            break;
        case 4:

        		cout << "=====================Aya Saleh===========================" << endl;
        		cout<<endl;
             int value, num_of_rounds,m;

    cout << "Please enter the seed value (must be 4 numbers): ";
    cin >> value;
    while (value<1000|| value>9999) {
        cout << "Please enter a positive number for the seed value must be four numbers: ";
        cin >> value;
    }

    cout << "Please enter the number of rounds (positive number  ): ";
    cin >> num_of_rounds;
    while (num_of_rounds <= 0) {
        cout << "Please enter a positive number  for the number of rounds: ";
        cin >> num_of_rounds;
    }

    cout<<"please enter m (must be greater than value) :";
    cin>>m;
    while (m <= value) {

    cout<<"please enter m (must be greater than value) :";
    cin>>m;
    cout<<endl;}

            MidSquare aayyaa;
            aayyaa.Random_mid(value, num_of_rounds,m);
            cout<< "Do you want complete (y/n) ?";
            cin>>x;
             if(x=='y'){
                    system("cls");
                   t.DisplayList();
                   t.names_list();
                   cout<<"please,select choice:"<<endl;
                   cin>>choice1;
                   system("cls");
	               t.chooseAlgorithm(choice1);

            }
            else{
                cout<<"Thank you :)"<<endl;
                exit(0);
            }
            break;
        case 3:
            cout<<"=====================Aya Mohamed*LFG*=================="<<endl;
       cout<<endl;
             LaggedFibonacciGenerator LFG;
             LFG.generateSequence();
              cout<< "Do you want complete (y/n) ?";
            cin>>x;
              if(x=='y'){
                    system("cls");
                   t.DisplayList();
                   t.names_list();
                   cout<<"please,select choice:"<<endl;
                   cin>>choice1;
                   system("cls");
	               t.chooseAlgorithm(choice1);

            }
            else{
                cout<<"Thank you :)"<<endl;
                exit(0);
            }
             break;

        }
    }
};

int getInputAsInt(const string& prompt) {
    int num;
    string input;

    do {
        cout << prompt;
        cin >> input;
        bool validInput = true;
        for (char c : input) {
            if (!isdigit(c)) {
                validInput = false;
                break;
            }
        }
        if (!validInput) {
            cout << "Invalid input. Please enter an integer.\n";
            continue;
        }
        try {
            num = stoi(input); // casting string to int
            break;
        } catch (exception e) {
            cout << "Invalid input. Please enter an integer.\n";
            cin.clear(); // clear error msg
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); // clear buffer from wrong ans
        }
    } while (true);
    return num;
}
int main()
{
system("color 3");
  cout << "\t\t";
  for (int r = 0; r < 20; r++)
	{
		cout << "=";
	}
  cout<<"Hello in our Modeling Project";
  for (int r = 0; r < 20; r++)
	{
		cout << "=";
	}
  cout<<endl<<endl;
  int answer;
  TeachingAssistant t;
  do {
        cout << "\t\t Please select your interaction partner: " << endl;
        cout << "\t\t 1. ENG/omar" << endl;
        cout << "\t\t 2. ENG/habiba" << endl;
        answer = getInputAsInt("\t\t PLEASE CHOOSE ONE: ");
        system("cls");

        if (answer == 1) {
            t.OmarPassword();
            t.DisplayList();
        } else if (answer == 2) {
            t.HabibaPassword();
     	    t.DisplayList();
        } else {
            cout << "\t\t Invalid choice. Please enter 1 or 2." << endl;
        }
    } while (answer != 1 && answer != 2);

	 t.names_list();
	 int choice;
	  do {
        choice = getInputAsInt("ENTER YOUR CHOICE: ");

        if (choice != 1 && choice != 2 && choice != 3 && choice != 4) {
            cout << "Invalid choice. Please enter 1, 2, 3, or 4." << endl;
        }
    } while (choice != 1 && choice != 2 && choice != 3 && choice != 4);
	 system("cls");
	 t.chooseAlgorithm(choice);
}
