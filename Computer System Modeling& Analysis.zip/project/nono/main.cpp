#include<iostream>
#include<cmath>
using namespace std;

class KS {
private:
    float D, D1_alpha, alpha;
    float *Dplus, *Dminus;
    float *row_one, *row_two;
    int n;
    float *numbers;

public:
    KS() {
        Dplus = nullptr;
        Dminus = nullptr;
        row_one = nullptr;
        row_two = nullptr;
        numbers = nullptr;
    }

    ~KS() {
        delete[] Dplus;
        delete[] Dminus;
        delete[] row_one;
        delete[] row_two;
        delete[] numbers;
    }

    void get_data() {
        cout << "How many numbers?:" << endl;
        cin >> n;


        numbers = new float[n];
        row_one = new float[n];
        row_two = new float[n];
        Dplus = new float[n];
        Dminus = new float[n];

        cout << "Enter " << n << " numbers" << endl;
        for (int i = 0; i < n; i++) {
            cout << "Enter " << i + 1 << " number:" << endl;
            cin >> numbers[i];
        }

        // Sorting array
        for (int i = 0; i < n; i++) {
            for (int j = i + 1; j < n; j++) {
                if (numbers[i] > numbers[j]) {
                    float temp = numbers[j];
                    numbers[j] = numbers[i];
                    numbers[i] = temp;
                }
            }
        }

    }

    void calculate() {
        for (int i = 0; i < n; i++) {
            int j;
            j = i + 1;
            row_one[i] = (float)j / n;
            row_two[i] = (float)i / n;
            Dplus[i] = row_one[i] - numbers[i];
            Dminus[i] = numbers[i] - row_two[i];
        }
    }

    void display() {
        cout << endl;
        float Dplusmax = Dplus[0];
        float Dminusmax = Dminus[0];
        for (int i = 1; i < n; i++) {
            if (Dplus[i] > Dplusmax) {
                Dplusmax = Dplus[i];
            }
            if (Dminus[i] > Dminusmax) {
                Dminusmax = Dminus[i];
            }
        }
        cout << "D+ max: " << Dplusmax << endl;
        cout << "D- max: " << Dminusmax << endl;
        cout << "D = max(" << Dplusmax << ", " << Dminusmax << ") =";
        if (Dplusmax > Dminusmax) {
            D = Dplusmax;
        } else {
            D = Dminusmax;
        }
        cout << D << endl;
    }

    void test_acceptance() {
        cout << "Enter the Alpha value:" << endl;
        cin >> alpha;
        double D1_alpha = sqrt(-0.5 * log(alpha / 2.0)) / sqrt(n);

        if (D < D1_alpha) {
            cout << "The test is accepted." << endl;
        } else {
            cout << "The test is rejected." << endl;
        }
    }
};

int main() {
    KS ks1;
    ks1.get_data();
    ks1.calculate();
    ks1.display();
    ks1.test_acceptance();

    return (0);
}
