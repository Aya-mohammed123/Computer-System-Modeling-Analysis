#include<iostream>
#include<conio.h>
#include<iomanip>
#include<cmath>
using namespace std;
class KS
{
private:
    //float numbers[20];
    float D,D1_alpha,alpha;
    float Dplusmax,Dminusmax;
    float Dplus[20],Dminus[20];
    float ratio[20],ratiominus[20];
    int i,j,n=20,temp;
    float numbers[n];


public:
    void get_data()
    {
        cout<<"How many numbers?:"<<endl;
        cin>>n;
        cout<<"Enter "<<n<<" numbers"<<endl;

        for(i=0;i<n;i++)
        {
            cout<<"Enter "<<i+1<<" number:"<<endl;
            cin>>numbers[i];
        }


        cout<<"The numbers in ascending order is:"<<endl;
        for(i=0;i<n;i++)
        {
            for(int j=i+1; j<n;j++){
                if(numbers[i]<numbers[j]){
                  temp = numbers[j];
                  numbers[j] = numbers[i];
                  numbers[i] = temp;

                }
            }
        }
         cout << "Sorted array in ascending order: ";
    for (int i = 0; i < n; ++i) {
        cout << numbers[i] << " ";
    }

    }

    void calculate()
    {
        for(i=0;i<n;i++)
        {
            int j;
            j=i+1;
            ratio[i]=(float)j/n;
            ratiominus[i]=(float)i/n;
            Dplus[i]=ratio[i]-numbers[i];
            Dminus[i]=numbers[i]-ratiominus[i];

        }
    }
    void display()
    {
        cout<<endl;
        Dplusmax=Dplus[0];
        Dminusmax=Dminus[0];
        for(i=1;i<n;i++)
        {
            if(Dplus[i]>Dplusmax)
            {
                Dplusmax=Dplus[i];
            }
            if(Dminus[i]>Dminusmax)
            {
                Dminusmax=Dminus[i];
            }
        }
        cout<<"D+ max: "<<Dplusmax<<endl;
        cout<<"D- max: "<<Dminusmax<<endl;
        cout<<"D =max("<<Dplusmax<<", "<<Dminusmax<<") =";
        if(Dplusmax>Dminusmax)
        {
            D=Dplusmax;
        }
        else
        {
            D=Dminusmax;
        }
        cout<<D;
        cout<<endl;

    }
    void test_acceptance()
    {
        cout<<"Enter the Alpha value:"<<endl;
        cin>>alpha;
        double D1_alpha = sqrt(-0.5 * log(alpha / 2.0)) / sqrt(n);

        if(D<D1_alpha)
        {
            cout<<"The test is accepted."<<endl;
        }
        else
        {
            cout<<"The test is rejected."<<endl;
        }
    }
};


int main()
{
    KS ks1;
    ks1.get_data();
   // ks1.ascending_order();
    ks1.calculate();
    ks1.display();
    ks1.test_acceptance();

    return (0);
}
